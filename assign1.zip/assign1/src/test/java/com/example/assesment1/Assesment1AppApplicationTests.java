package com.example.assesment1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assesment1AppApplicationTests {

	@Test
	void contextLoads() {
	}

}
