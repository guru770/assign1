package com.example.assesment1.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.assesment1.model.Product;
import com.example.assesment1.exception.ResourceNotFoundException;

import java.util.List;

import com.example.assesment1.dao.ProductRepository;

@Service
public class ProductService {
	
	@Autowired
	ProductRepository productrep;

	public Product CreateProduct(Product product) {
		return productrep.save(product);
	}
	public Optional<Product> Search(Integer productid) {
		
		return productrep.findById( productid);
	}
	public List<Product> getAllProduct() 
	{
		List<Product> products = new ArrayList<Product>();
	productrep.findAll().forEach(product -> products.add(product));
	return products;
	}
	
	//deleting a specific record if rating < 2
	public void deleteProduct() 
	{
		List<Product> product = productrep.findAll();
		for(Product p: product) {
			if(p.getRating() < 2) {
				productrep.delete(p);
			}
			
		}
		
	}
	public Product updateProduct(Integer productid) throws ResourceNotFoundException {
		Product prod=productrep.findById(productid)
				.orElseThrow(() -> new com.example.assesment1.exception.ResourceNotFoundException("product not found for this id :: " + productid));
		int Qty = prod.getQty();
		int unitPrice = prod.getUnitprice();
		prod.setTotalprice(Qty * unitPrice);
		return prod;
		
		
	}
}
