package com.example.assesment1.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.assesment1.service.ProductService;


import java.util.List;

import com.example.assesment1.model.Product;
import com.example.assesment1.exception.ResourceNotFoundException;

@RestController
@RequestMapping("/productInventory")
public class ProductController {
	
	@Autowired
	ProductService ProdSer;
	
	//method to add the products into the inventory
	@PostMapping("/product")
	public Product CreateProduct(@RequestBody Product product) {
		return ProdSer.CreateProduct(product);
	}
	
	//method to search all products from inventory
	@GetMapping("SearchAllProduct")
	private List<Product> getAllProduct() 
	{
	return ProdSer.getAllProduct();
	}
	
	// method to search the specific product based on product id
	@GetMapping("SearchProduct/{id}")
	public Optional<Product> SearchProduct(@PathVariable(value = "id") Integer productid) {
		return ProdSer.Search(productid);
	}
	
	//creating a delete mapping that deletes a specific product
	@DeleteMapping("/deleteProduct")
	private void deleteProduct() 
	{
		ProdSer.deleteProduct();
	}
	
	//this method is to update inventory to calculate totalPrice
	@PutMapping("/updateProduct/{id}")
	public Product updateProduct(@PathVariable(value = "id") Integer productid) throws ResourceNotFoundException {
		
		return ProdSer.updateProduct(productid);
		
	}
}
